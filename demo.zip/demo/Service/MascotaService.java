package com.example.demo.Service;

import java.util.List;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.DTO.MascotaSolicitud;
import com.example.demo.DTO.RespuestaApi;
import com.example.demo.Model.Mascota;
import com.example.demo.Model.Usuario;
import com.example.demo.Repository.MascotaRepository;
import com.example.demo.Repository.UsuarioRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MascotaService {
    
    private final MascotaRepository mascotaRepository;
    private final UsuarioRepository usuarioRepository;
    
    @Transactional
    public RespuestaApi registrarMascota(MascotaSolicitud solicitud, String correo) {
        correo = SecurityContextHolder.getContext().getAuthentication().getName();
        Usuario cliente = usuarioRepository.findByCorreo(correo)
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
        
        if (!"CLIENTE".equals(cliente.getRol())) {
            return RespuestaApi.error("Solo los clientes pueden registrar mascotas");
        }
        
        if (mascotaRepository.existsByClienteIdAndNombre(cliente.getId(), solicitud.getNombre())) {
            return RespuestaApi.error("Ya tienes una mascota con ese nombre");
        }
        
        Mascota mascota = Mascota.builder()
                .cliente(cliente)
                .nombre(solicitud.getNombre())
                .tipo(solicitud.getTipo())  // ← String "PERRO" o "GATO"
                .raza(solicitud.getRaza())
                .edad(solicitud.getEdad())
                .fotoUrl(solicitud.getFotoUrl())
                .cliente(cliente)
                .build();
        
        mascotaRepository.save(mascota);
        
        return RespuestaApi.exito("Mascota registrada exitosamente", mascota);
    }
    
    public RespuestaApi listarMisMascotas(String correo) {
        correo = SecurityContextHolder.getContext().getAuthentication().getName();
        Usuario cliente = usuarioRepository.findByCorreo(correo)
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
        
        List<Mascota> mascotas = mascotaRepository.findByClienteId(cliente.getId());
        
        return RespuestaApi.exito("Mascotas obtenidas", mascotas);
    }
}